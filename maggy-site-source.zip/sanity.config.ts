"use client";
import { defineConfig } from "sanity";
import { structureTool } from "sanity/structure";
import { visionTool } from "@sanity/vision";
import { schemaTypes } from "./sanity/schemaTypes";

export default defineConfig({ name: "maggy-portfolio", title: "Maggy / 肖尧内容管理", projectId: process.env.NEXT_PUBLIC_SANITY_PROJECT_ID || "placeholder", dataset: process.env.NEXT_PUBLIC_SANITY_DATASET || "production", plugins: [structureTool(), visionTool()], schema: { types: schemaTypes } });
